import java.util.*;
/**
 * Represents a region of the board that 
 * is updated when a square within the region
 * is changed.
 * 
 * @author Maria Vazhaeparambil
 * @version May 31, 2018
 */
public class Region extends Sudoku implements Section 
                    
{
    private int startRow;
    private int startCol;

    /**
     * Constructor for objects of class Region
     * 
     * @param row the row which the region starts from
     * @param col the col which the region starts from
     */
    public Region(int row, int col)
    {
        startRow = row;
        startCol = col;
    }

    /**
     * Updates the region based on the square that has been changed.
     * 
     * @param  square  the board data that holds all the Sudoku information
     * @param  aSquare the specific square in the board that has been changed
     */
    public void update(Square[][] square, Square aSquare)
    {
        for(int r = startRow; r < startRow + 3; r++)
        {
            for(int c = startCol; c < startCol + 3; c++)
            {
                if(square[r][c].getValue() == 0)
                    square[r][c].removePossibleValue(aSquare.getValue());
            }
        } 
    }
    
    /**
     * Returns a pair of possible integers that is the same for two squares in the region.
     *
     * @param  square  is the board data that holds all Sudoku information
     * 
     * @return array of int of length two that contains the first pair of
     * possible values that occur in two squares of this sevtion;
     * returns null if no such pair exists
     */
    public ArrayList<Integer> get(Square[][] square)
    {
        for(int r = startRow; r < startRow + 3; r++)
        {
            for(int c = startCol; c < startCol + 3; c++)
            {
                ArrayList<Integer> check = square[r][c].returnPossible();
                if(check.size() == 2)
                {
                    for(int row = r; row < startRow + 3; row++)
                    {
                        for(int col = c; col < startCol + 3; col++)
                        {
                            if(square[row][col].returnPossible().equals(check))
                                return check;
                        }
                    }
                }
            }    
        }
        return null;
    }
    
    /**
     * Removes all other instances of this value in the region.
     * 
     * @param  square is the board data that holds all Sudoku information
     * @param  pair   array of int of length two that contains a pair of
     *                possible values; removes the two values from all squares 
     *                not having the pair as their own possible values
     */
    public void process(Square[][] square, ArrayList<Integer> pair)
    {
        int count = 0;
        for(int r = startRow; r < startRow + 3; r++)
        {   
            for(int c = startCol; c < startCol + 3; c++)
            {
                if(square[r][c].returnPossible().equals(pair))
                {
                    count++;
                }
            }
        }
        if(count == pair.size())
        {
            for(int r = startRow; r < startRow + 3; r++)
            {   
                for(int c = startCol; c < startCol + 3; c++)
                {
                    if(!square[r][c].returnPossible().equals(pair))
                    {
                        for(int i = pair.size() - 1; i >= 0; i--)
                            square[r][c].removePossibleValue(pair.get(i));
                    }
                }
            }
        }
    }
    
    
    /**
     * Checks whether there is only one possibile location for a number within a region.
     * 
     * @param  square  is the board data that holds all Sudoku information
     */
    public void check(Square[][] square)
    {
        int count = 0;
        int row = -1;
        int col = -1;
        for(int i = 1; i <= 9; i++)
        {
            for(int r = startRow; r < startRow + 3; r++)
            {
                for(int c = startCol; c < startCol + 3; c++)
                {
                    if(square[r][c].getValue() == i)
                        count += 2;
                    if(square[r][c].isPossible(i))
                    {
                        count++;
                        row = r;
                        col = c;
                    }
                }
            }    
            if(count == 1)
            {
                square[row][col].setValue(i);
            }
            count = 0;
        }
    }
    
    /**
     * Checks whether the region has one of every number.
     * 
     * @param square is the board data that holds all the Sudoku information
     * 
     * @return true, if the region is complete and has every value, otherwise,
     *          false
     */
    public boolean checkRegion(Square[][] square)
    {
        int sum = 0;
        for(int r = startRow; r < startRow + 3; r++)
        {
            for(int c = startCol; c < startCol + 3; c++)
            {
                sum += square[r][c].getValue();
            }
        }
        return sum == 45;
    }
    
    /**
     * Checks whether the only possibilites of a number lie in one column.
     * 
     * @param square is the board data that holds all the Sudoku information
     */
    public void singleColumn(Square[][] square)
    {
        for(int i = 1; i <= 9; i++)
        {
            ArrayList<Integer> cols = new ArrayList<Integer>();
            for(int r = startRow; r < startRow + 3; r++)
            {
                for(int c = startCol; c < startCol + 3; c++)
                {
                    if(square[r][c].isPossible(i))
                    {
                        cols.add(c);
                    }
                }
            }
            
            boolean check = true;
            for(int n = 1; n < cols.size(); n++)
            {
                if(cols.get(n - 1) != cols.get(n))
                    check = false;
            }
            
            if(check && cols.size() > 0)
                processC(square, cols.get(0), i);
        }
    }
    
    /**
     * Processes since the square is only possible in one column of the region.
     * 
     * @param square is the board data that holds all the Sudoku information
     * @param cnum   the only column of the region which a value is possible
     * @param num    the number that is only possible in one column of the region
     */
    public void processC(Square[][] square, int cnum, int num)
    {
        for(int r = 0; r < 9; r++)
        {
            if(r < startRow || r  >= startRow + 3)
                square[r][cnum].removePossibleValue(num);
        }
    }
    
    /**
     * Checks whether the only possibilites of a number lie in one row.
     * 
     * @param square is the board data that holds all the Sudoku information
     */
    public void singleRow(Square[][] square)
    {
        for(int i = 1; i <= 9; i++)
        {
            ArrayList<Integer> rows = new ArrayList<Integer>();
            for(int r = startRow; r < startRow + 3; r++)
            {
                for(int c = startCol; c < startCol + 3; c++)
                {
                    if(square[r][c].isPossible(i))
                    {
                        rows.add(r);
                    }
                }
            }
            
            boolean check = true;
            for(int n = 1; n < rows.size(); n++)
            {
                if(rows.get(n - 1) != rows.get(n))
                    check = false;
            }
            
            if(check && rows.size() > 0)
                processR(square, rows.get(0), i);
        }
    }
    
    /**
     * Processes since the square is only possible in one row of the region.
     * 
     * @param square is the board data that holds all the Sudoku information
     * @param rnum   the only row of the region which a value is possible
     * @param num    the number that is only possible in one row of the region
     */
    public void processR(Square[][] square, int rnum, int num)
    {
        for(int c = 0; c < 9; c++)
        {
            if(c < startCol || c  >= startCol + 3)
                square[rnum][c].removePossibleValue(num);
        }
    }
}
