import java.util.*;
/**
 * Represents a column of the board that 
 * is updated when a square within the column
 * is changed.
 * 
 * @author Maria Vazhaeparambil
 * @version May 31, 2018
 */
public class Column implements Section
{
    private int colNum;

    /**
     * Constructor for objects of class Column
     * 
     * @param num the number used to define which column in the sudoku this is
     */
    public Column(int num)
    {
        colNum = num;
    }

    /**
     * Updates the column based on the square that has been changed.
     * 
     * @param  square  the board data that holds all the Sudoku information
     * @param  aSquare the specific square in the board that has been changed
     */
    public void update(Square[][] square, Square aSquare)
    {
        if(aSquare.getCol() == colNum)
        {
            for(int item = 0; item < square[0].length; item++)
            {
                if(square[item][colNum].getValue() != aSquare.getValue())
                    square[item][colNum].removePossibleValue(aSquare.getValue());
            }
        }
    }
    
    /**
     * Returns a pair of possible integers that is the same for two squares in the column.
     * 
     * @param  square  is the board data that holds all Sudoku information
     * 
     * @return array of int of length two that contains the first pair of
     * possible values that occur in two squares of this section;
     * returns null if no such pair exists
     */
    public ArrayList<Integer> get(Square[][] square)
    {
        for(int item = 0; item < square.length; item++)
        {
            ArrayList<Integer> check = square[item][colNum].returnPossible();
            if(check.size() == 2)
            {
                for(int next = item + 1; next < square.length; next++)
                {
                    if(square[next][colNum].returnPossible().equals(check))
                        return check;
                }    
            }
        }
        return null;
    }
    
    /**
     * Removes all other instances of this value in the column.
     * 
     * @param  square is the board data that holds all Sudoku information
     * @param  pair   array of int of length two that contains a pair of
     *                possible values; removes the two values from all squares 
     *                not having the pair as their own possible values
     */
    public void process(Square[][] square, ArrayList<Integer> pair)
    {
        int count = 0;
        for(int r = 0; r < square.length; r++)
        {   
            if(square[r][colNum].returnPossible().equals(pair))
            {
                count++;
            }
        }
        if(count == pair.size())
        {
            for(int r = 0; r < square.length; r++)
            {   
                if(!square[r][colNum].returnPossible().equals(pair))
                {
                    for(int i = pair.size() - 1; i >= 0; i--)
                        square[r][colNum].removePossibleValue(pair.get(i));
                }
            }
        }
    }
        
    /**
     * Checks whether there is only one possibile location for a number within a column.
     * 
     * @param  square  is the board data that holds all Sudoku information
     */
    public void check(Square[][] square)
    {
        int count = 0;
        int row = -1;
        for(int i = 1; i <= 9; i++)
        {
            for(int r = 0; r < square.length; r++)
            {
                if(square[r][colNum].getValue() == i)
                    count += 2;
                if(square[r][colNum].isPossible(i))
                {
                    count++;
                    row = r;
                }
            }    
            if(count == 1)
            {
                square[row][colNum].setValue(i);
            }
            count = 0;
        }
    }
    
    /**
     * Checks whether the column has one of every number.
     * 
     * @param square is the board data that holds all the Sudoku information
     * 
     * @return true, if the column is complete and has every value, otherwise,
     *          false
     */
    public boolean checkCol(Square[][] square)
    {
        int sum = 0;
        for(int r = 0; r < square.length; r++)
        {
            sum += square[r][colNum].getValue();
        }
        return sum == 45;
    }
}
