import java.util.*;
/**
 * Board class models the 9 by 9 rectangular array of squares.
 * Each square can be blank or have an integer value 1 through 9.
 * Each square allso has a list of possible values that may be used
 * for that square's value.
 * 
 * @author Maria Vazhaeparambil
 * @version May 31, 2018
 */
public class Board extends Sudoku
{
    private Square[][] square;
    private Row[] rows = {new Row(0), new Row(1), new Row(2),
                          new Row(3), new Row(4), new Row(5),
                          new Row(6), new Row(7), new Row(8)};
    private Column[] cols = {new Column(0), new Column(1), new Column(2),
                             new Column(3), new Column(4), new Column(5),
                             new Column(6), new Column(7), new Column(8)};
    private Region[] regions = {new Region(0, 0), new Region(0, 3), new Region(0, 6),
                                new Region(3, 0), new Region(3, 3), new Region(3, 6),
                                new Region(6, 0), new Region(6, 3), new Region(6, 6)};
    /**
     * Constructor for objects of class Board
     */
    public Board()
    {
        square = new Square[9][9];
        sectionsInit();
    }

    /**
     * Initiates all squares to new squares.
     */
    public void squareInit()
    {
        for(int r = 0; r < square.length; r++)
        {
            for(int c = 0; c < square[r].length; c++)
            {
                square[r][c] = new Square(r, c, 0);
            }
        }
    }

    /** 
     * Initiates all aspects of the sudoku.
     */
    public void sectionsInit()
    {
        squareInit();
        boolean check = false;
        for(int r = 0; r < square.length; r++)
        {

            rows[r] = new Row(r);
            for(int c = 0; c < square[r].length; c++)
            {
                if(!check)
                {
                    cols[c] = new Column(c);
                    if(c == 8)
                        check = true;
                }

                if(r % 3 == 0 && c % 3 == 0)
                {
                    regions[r + c / 3] = new Region(r, c);
                }
            }
        }
    }

    /**
     * Updates the sudoku based on the given value 
     * assigned to a given row and column.
     * 
     * @param row  the row the number is assigned
     * @param col  the col the number is assigned
     * @param val  the value of the number
     */
    public void updateSections(int row, int col, int val)
    {
        square[row][col].setValue(val);
        rows[row].update(square, square[row][col]);
        cols[col].update(square, square[row][col]);
        regions[(row / 3) * 3 + col / 3].update(square, square[row][col]);
        if(rows[row].get(square) != null)
            rows[row].process(square, rows[row].get(square));
        if(cols[col].get(square) != null)
            cols[col].process(square, cols[col].get(square));
        if(regions[row / 3 * 3 + col / 3].get(square) != null)
        {
            regions[row/3*3+col/3].process(square,regions[row/3*3+col/3].get(square));
        }

    }

    /**
     * Printing the sudoku in the format of a sudoku.
     */
    public void print()
    {
        for(int r = 0; r < square.length; r++)
        {
            for(int c = 0; c < square[r].length; c++)
            {
                System.out.print(square[r][c].getValue() + " ");
                if(c == 8)
                {
                    System.out.println();
                    if(r % 3 == 2)
                        System.out.println();
                }
                else if(c % 3 == 2)
                    System.out.print("\t");    
            }
        }
    }

    /**
     * Updates all squares of the sudoku based on the known values.
     */
    public void change()
    {
        boolean check = false;
        for(int i = 0; i < 9; i++)
        {
            rows[i].check(square);
            cols[i].check(square);
            regions[i].check(square);
            regions[i].singleRow(square);
            regions[i].singleColumn(square);
        }

        for(int r = 0; r < square.length; r++)
        {
            for(int c = 0; c < square[r].length; c++)
            {
                if(square[r][c].getValue() == 0)
                {
                    square[r][c].found();
                    check = true;
                }
                else
                    updateSections(r, c, square[r][c].getValue());
            }    
        }
    }    

    /**
     * Returns the contents of the sudoku.
     * 
     * @return a 2Darray acting as the sudoku
     */
    public Square[][] getSquare()
    {
        return square;
    }

    /**
     * Sets a given square with a specific value.
     * 
     * @param r    the row of the square being set
     * @param c    the column of the square being set
     * @param val  the value that the square will be set to
     */
    public void setSquare(int r, int c, int val)
    {
        square[r][c].setValue(val);
    }

    /**
     * Compares the values of this sudoku to the values of another sudoku.
     * 
     * @param template  the sudoku that this sudoku is being compared to 
     * 
     * @return true, if the values of both sudokus are the same, otherwise
     *          false
     */
    public boolean compare(Board template)
    {
        boolean ans = true;
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                if((template.getSquare())[r][c].getValue() != (this.getSquare())[r][c].getValue())
                    ans = false;
            }   
        }
        return ans;
    }

    /**
     * Solves this sudoku.
     */
    public void solved()
    {
        Board template = new Board();
        while(!compare(template))
        {
            for(int r = 0; r < 9; r++)
            {
                for(int c = 0; c < 9; c++)
                {
                    template.updateSections(r, c, ((getSquare())[r][c]).getValue());
                }
            }
            change();
        }
        yWing();
        while(!compare(template))
        {
            for(int r = 0; r < 9; r++)
            {
                for(int c = 0; c < 9; c++)
                {
                    template.updateSections(r, c, ((getSquare())[r][c]).getValue());
                }
            }
            change();
        }
    }

    /**
     * Implements the YWing strategy on this sudoku.
     */
    public void yWing()
    {
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                if(square[r][c].getValue() == 0)
                    sqrycheck(r, c, square[r][c].returnPossible());
            }
        }
    }

    /**
     * Implements YWing strategy for all arrangements of two values for the square.
     * 
     * @param row       the row of the square being checked for YWing strategy
     * @param col       the column of the square being checked for YWing strategy
     * @param possible  an array of all the possibilities in the square
     */
    public void sqrycheck(int row, int col, ArrayList<Integer> possible)
    {
        for(int i = 0; i < possible.size(); i++)
        {
            for(int j = 0; j < possible.size(); j++)
            {
                if(i != j && i < square[row][col].returnPossible().size() && 
                    j < square[row][col].returnPossible().size())
                {
                    ycheck(row, col, possible.get(i), possible.get(j));
                }
            }
        }
    }

    /**
     * Checks if the YWing can eliminate any values for a square given two possible values.
     * 
     * @param row   the row of the square
     * @param col   the column of the square
     * @param val1  a possible value of the square
     * @param val2  another possible value of the square
     */
    public void ycheck(int row, int col, int val1, int val2)
    {
        ArrayList<Integer> possibleRows = new ArrayList<Integer>();
        for(int r = 0; r < 9; r++)
        {
            if(square[r][col].isPossible(val1))
                possibleRows.add(r);
        }   
        ArrayList<Integer> possibleCols = new ArrayList<Integer>();
        for(int c = 0; c < 9; c++)
        {
            if(square[row][c].isPossible(val2))
                possibleCols.add(c);
        }

        for(int i = 0; i < possibleRows.size(); i++)
        {
            for(int j = 0; j < possibleCols.size(); j++)
            {
                for(int x = 1; x <= 9; x++)
                {
                    if(square[possibleRows.get(i)][col].returnPossible().size() == 2
                        && square[row][possibleCols.get(j)].returnPossible().size() == 2
                        && square[possibleRows.get(i)][col].isPossible(x)
                        && square[row][possibleCols.get(j)].isPossible(x)
                        && square[possibleRows.get(i)][possibleCols.get(j)].isPossible(x))
                    {
                        square[possibleRows.get(i)][possibleCols.get(j)].removePossibleValue(x);
                        change();
                    }
                }
            }
        }
    }

    /**
     * Creates a random sudoku solution.
     */
    public void create()
    {
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                int rand = (int)(Math.random() * square[r][c].returnPossible().size());
                ArrayList poss = new ArrayList();
                for(int i = 0; i < square[r][c].returnPossible().size(); i++)
                {
                    if(i != rand)
                        poss.add(square[r][c].returnPossible().get(i));
                }
                if(square[r][c].returnPossible().size() == 0)
                {
                    sectionsInit();
                    create();
                }
                square[r][c].setValue(square[r][c].returnPossible().get(rand));
                for(int i = 0; i < 10; i++)
                    change();
                if(!check())
                {
                    square[r][c] = new Square(r, c, 0);
                    for(int i = 0; i < poss.size(); i++)
                    {
                        square[r][c].setPossible(poss);
                    }
                }
            }
        }
        if(!right())
            create();
    }

    /**
     * Checks whether the sudoku is correct or not.
     * 
     * @return true, if the sudoku is solved, otherwise,
     *          false
     */
    public boolean right()
    {
        boolean check = true;
        for(int i = 0; i < 9; i++)
        {
            if(!rows[i].checkRow(square) || !cols[i].checkCol(square) 
                || !regions[i].checkRegion(square))
            {
                check = false;
            }
        }
        return check;
    }

    /**
     * Checks whether any square has no solution while being solved.
     * 
     * @return true, if there are no solutions for any square in the sudoku, otherwise
     *          false
     */
    public boolean check()
    {
        for (int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                if(square[r][c].returnPossible().size() == 0)
                    return false;
            }
        }
        return true;
    }

    /**
     * Checks whether any square is still equal to 0.
     * 
     * @return true, if no squares have a value of 0, otherwise
     *          false
     */
    public boolean see0()
    {
        for (int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                if(square[r][c].returnPossible().size() == 0)
                    return false;
                if(square[r][c].getValue() == 0)
                    return false;
            }
        }
        return true;
    }

    /**
     * Deletes random values in the sudoku solution until the sudoku is unsolvable.
     */
    public void delete()
    {
        Board copy = new Board();
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                Square[][] temp = copy.getSquare();
                temp[r][c] = new Square(r, c, square[r][c].getValue());
            }
        } 
        int r = (int)(Math.random() * 9);
        int c = (int)(Math.random() * 9);
        copy.getSquare()[r][c].reset();
        copy.getSquare()[8 - r][8 - c].reset();
        copy.solvedE();
        if(copy.see0() && unique(copy))
        {
            square[r][c].reset();
            square[8 - r][8 - c].reset();
            delete();
        }
    }

    /**
     * Removes every value that is not needed to solve the sudoku.
     */
    public void hard()
    {
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                Board copy = new Board();
                Square[][] temp = copy.getSquare();
                for(int ro = 0; ro < 9; ro++)
                {
                    for(int co = 0; co < 9; co++)
                    {
                        temp[ro][co] = new Square(ro, co, square[ro][co].getValue());
                    }
                } 
                temp[r][c].reset();
                temp[8 - r][8 - c].reset();
                copy.solvedE();
                if(copy.see0() && unique(copy))
                {
                    square[r][c].reset();
                    square[8 - r][8 - c].reset();
                }
            }
        }

        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                Board copy = new Board();
                Square[][] temp = copy.getSquare();
                for(int ro = 0; ro < 9; ro++)
                {
                    for(int co = 0; co < 9; co++)
                    {
                        temp[ro][co] = new Square(ro, co, square[ro][co].getValue());
                    }
                } 
                temp[r][c].reset();
                copy.solvedE();
                if(copy.see0() && unique(copy))
                {
                    square[r][c].reset();
                }
            }
        }
    }

    /**
     * Solves this easy sudoku.
     */
    public void solvedE()
    {
        Board template = new Board();
        while(!compare(template))
        {
            for(int r = 0; r < 9; r++)
            {
                for(int c = 0; c < 9; c++)
                {
                    template.updateSections(r, c, ((getSquare())[r][c]).getValue());
                }
            }
            change();
        }
    }

    /**
     * Creates a hard sudoku using the easy methods.
     */
    public void hardE()
    {
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                Board copy = new Board();
                Square[][] temp = copy.getSquare();
                for(int ro = 0; ro < 9; ro++)
                {
                    for(int co = 0; co < 9; co++)
                    {
                        temp[ro][co] = new Square(ro, co, square[ro][co].getValue());
                    }
                } 
                temp[r][c].reset();
                temp[8 - r][8 - c].reset();
                copy.solvedE();
                if(copy.see0() && unique(copy))
                {
                    square[r][c].reset();
                    square[8 - r][8 - c].reset();
                }
            }
        }
    }
    
    /**
     * Checks to make sure the board has one solution.
     * 
     * @param temp the Board that this sudoku is being checked with
     * 
     * @return true, if the sudoku is unique, otherwise,
     *          false
     */
    public boolean unique(Board temp)
    {
        Board template = new Board();
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                template.updateSections(r, c, square[r][c].getValue());
            }
        }
        Board template2 = new Board();
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                template2.updateSections(r, c, temp.getSquare()[r][c].getValue());
            }
        }
        template.solved();
        boolean check = true;
        for(int r = 0; r < 9; r++)
        {
            for(int c = 0; c < 9; c++)
            {
                if(template.getSquare()[r][c].getValue() != template2.getSquare()[r][c].getValue())
                    check = false;
            }
        }
        return check;
    }
}
