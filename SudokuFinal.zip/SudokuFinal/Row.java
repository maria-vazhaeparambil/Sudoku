import java.util.*;
/**
 * Represents a column of the board that 
 * is updated when a square within the column
 * is changed.
 * 
 * @author Maria Vazhaeparambil
 * @version May 31, 2018
 */
public class Row implements Section 
{
    private int rowNum;

    /**
     * Constructor for objects of class Row
     * 
     * @param num the number used to define which row in the sudoku this is
     */
    public Row(int num)
    {
        rowNum = num;
    }

    /**
     * Updates the row based on the square that has been changed.
     * 
     * @param  square  the board data that holds all the Sudoku information
     * @param  aSquare the specific square in the board that has been changed
     */
    public void update(Square[][] square, Square aSquare)
    {
        if(aSquare.getRow() == rowNum)
        {
            for(int item = 0; item < square.length; item++)
            {
                if(square[rowNum][item].getValue() != aSquare.getValue())
                    square[rowNum][item].removePossibleValue(aSquare.getValue());
            }
        }
    }

    /**
     * Returns a pair of possible integers that is the same for two squares in the row.
     *
     * @param  square  is the board data that holds all Sudoku information
     * 
     * @return array of int of length two that contains the first pair of
     * possible values that occur in two squares of this sevtion;
     * returns null if no such pair exists
     */
    public ArrayList<Integer> get(Square[][] square)
    {
        for(int item = 0; item < square.length; item++)
        {
            ArrayList<Integer> check = square[rowNum][item].returnPossible();
            if(check.size() == 2)
            {
                for(int next = item + 1; next < square.length; next++)
                {
                    if(square[rowNum][next].returnPossible().equals(check))
                        return check;
                }
            }
        }
        return null;
    }

    /**
     * Removes all other instances of this value in the row.
     * 
     * @param  square is the board data that holds all Sudoku information
     * @param  pair   array of int of length two that contains a pair of
     *                possible values; removes the two values from all squares 
     *                not having the pair as their own possible values
     */
    public void process(Square[][] square, ArrayList<Integer> pair)
    {
        int count = 0;
        for(int c = 0; c < square[0].length; c++)
        {   
            if(square[rowNum][c].returnPossible().equals(pair))
            {
                count++;
            }
        }
        if(count == pair.size())
        {
            for(int c = 0; c < square[0].length; c++)
            {   
                if(!square[rowNum][c].returnPossible().equals(pair))
                {
                    for(int i = pair.size() - 1; i >= 0; i--)
                        square[rowNum][c].removePossibleValue(pair.get(i));
                }
            }
        }
    }
    
    /**
     * Checks whether there is only one possibile location for a number within a row.
     * 
     * @param  square  is the board data that holds all Sudoku information
     */
    public void check(Square[][] square)
    {
        int count = 0;
        int col = -1;
        for(int i = 1; i <= 9; i++)
        {
            for(int c = 0; c < square[rowNum].length; c++)
            {
                if(square[rowNum][c].getValue() == i)
                    count += 2;
                if(square[rowNum][c].isPossible(i))
                {
                    count++;
                    col = c;
                }
            }    
            if(count == 1)
            {
                square[rowNum][col].setValue(i);
            }
            count = 0;
        }
    }
    
    /**
     * Checks whether the row has one of every number.
     * 
     * @param square is the board data that holds all the Sudoku information
     * 
     * @return true, if the column is complete and has every value, otherwise,
     *          false
     */
    public boolean checkRow(Square[][] square)
    {
        int sum = 0;
        for(int c = 0; c < square[rowNum].length; c++)
        {
            sum += square[rowNum][c].getValue();
        }
        return sum == 45;
    }
    
}
