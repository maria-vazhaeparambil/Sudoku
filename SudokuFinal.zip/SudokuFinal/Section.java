import java.util.*;
/**
 * Represents a portion of the board that must be
 * updated when a board square contained within this
 * section is modified.
 * 
 * @author Maria Vazhaeparambil
 * @version February 22, 2018
 */
public interface Section
{
    /**
     * Updates the board based on the square that has been changed.
     * 
     * @param  square  is the board data that holds all Sudoku information
     * @param  aSquare  is the Square used to update all Section values
     */
    void update(Square[][] square, Square aSquare);
    
    /**
     * Returns the pair in the section that occurs twice.
     * 
     * @param  square  is the board data that holds all Sudoku information
     * 
     * @return array of int of length two that contains the first pair of
     * possible values that occur in two squares of this section;
     * returns null if no such pair exists
     */
    ArrayList<Integer> get(Square[][] square);
    
    /**
     * Removes all other instances of the given pair.
     * 
     * @param  square is the board data that holds all Sudoku information
     * @param  pair   array of int of length two that contains a pair of
     *                possible values; removes the two values from all squares 
     *                not having the pair as their own possible values
     */
    void process(Square[][] square, ArrayList<Integer> pair);
}
